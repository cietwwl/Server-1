package com.rwbase.common.cache;

public class CacheStackTrace extends Exception {

//	public CacheStackTrace() {
//		super("only cache stack trace");
//	}
	
}
