package com.rwbase.common.cache;

import java.util.List;

import com.rw.fsutil.cacheDao.mapItem.IMapItem;
import com.rw.fsutil.cacheDao.mapItem.MapItemDao;

public class UpdateEvent<T extends IMapItem> {

	private final MapItemDao<T> dao;
	private final List<T> items;

	public UpdateEvent(MapItemDao<T> dao, List<T> items) {
		this.dao = dao;
		this.items = items;
	}

	public MapItemDao<T> getDao() {
		return dao;
	}

	public List<T> getItems() {
		return items;
	}

}
