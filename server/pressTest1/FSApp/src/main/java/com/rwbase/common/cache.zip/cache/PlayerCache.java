package com.rwbase.common.cache;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantLock;

import com.playerdata.Player;

/**
 * LRU缓存 1.在{@link PersistentLoader}与{@link LRUCacheListener}
 * 的各方法中如果有获取锁需注意这把锁的使用， 如外部有地方先获取锁，调用缓存中的各方法，则有可能死锁
 * 
 * @author Jamaz
 */
public class PlayerCache {

	private static final Object PRESENT = new Object();
	private final ReentrantLock lock;
	private final LinkedHashMap<String, Player> cache; // 数据集合
	private final ConcurrentHashMap<String, Object> delayUpdateMap; // 延迟更新任务，表示一个一段时间后执行的任务
	private final ConcurrentHashMap<String, ReentrantFutureTask> taskMap; // 任务集合，表示一个以主键互斥的任务
	private final ConcurrentHashMap<String, Object> penetrationCache; // 缓存穿透，表示在数据库找不到的任务，缓存一段时间防止缓存穿透
	private final PersistentLoader<String,Player> loader;
	private final int capacity;
	private final int updatePeriod;
	private final long timeoutNanos;
	private final ScheduledThreadPoolExecutor scheduledExecutor;
	private final LRUCacheListener<String, Player> listener;
	private CacheLogger logger;

	static AtomicLong evcitDeleted = new AtomicLong();
	static AtomicLong evcitMarkDeleted = new AtomicLong();

	public PlayerCache(String name, int initialCapacity, int maxCapacity, int updatePeriod, ScheduledThreadPoolExecutor scheduledExecutor, PersistentLoader loader, LRUCacheListener<String, Player> listener) {
		this.capacity = maxCapacity;
		this.logger = CacheFactory.getLogger(name);
		this.lock = new ReentrantLock();
		this.scheduledExecutor = scheduledExecutor;
		this.updatePeriod = updatePeriod;
		this.delayUpdateMap = new ConcurrentHashMap<String, Object>(initialCapacity, 0.5f);
		this.taskMap = new ConcurrentHashMap<String, ReentrantFutureTask>();
		this.penetrationCache = new ConcurrentHashMap<String, Object>();
		this.loader = loader;
		this.timeoutNanos = TimeUnit.SECONDS.toNanos(6);
		this.cache = new LinkedHashMap<String, Player>(initialCapacity, 0.5f, true) {

			@Override
			protected boolean removeEldestEntry(Entry<String, Player> eldest) {
				if (size() > capacity) {
					String key = eldest.getKey();
					logger.info("evict:" + key);
					Player value = eldest.getValue();
					// 有一种情况是添加失败的，就是这个数据刚被加载进来
					ReentrantFutureTask evictedTask = createTask(new EvictedTask(key, value));
					// 还没来得及执行finnaly的时候又被T走，这个可能性极低，而且也超过了缓存的负载能力
					if (PlayerCache.this.taskMap.putIfAbsent(key, evictedTask) != null) {
						logger.error("严重错误@缓存添加移除任务失败:" + key);
					} else {
						logger.info("添加主键任务：" + key + "," + evictedTask);
						PlayerCache.this.scheduledExecutor.schedule(evictedTask, 0, TimeUnit.NANOSECONDS);
					}
					return true;
				}
				return false;
			}
		};
		this.listener = listener;
		this.logger.info("create DAO = " + name + ",maxCapacity = " + maxCapacity + ",updatePeriod = " + updatePeriod);
	}

	/**
	 * 获取指定元素，如果不存在，尝试从数据库中加载该主键对应的元素
	 * 
	 * @param key
	 *            元素的主键
	 * @return 指定的元素
	 * @throws InterruptedException
	 *             在加载的过程中可能抛出{@link InterruptedException}，但此时不能确定元素是否已经加载完成
	 * @throws Throwable
	 *             在加载的过程中可能抛出其他的异常，需要自己进行捕捉
	 */
	public Player getOrLoadFromDB(String key) throws InterruptedException, Throwable {
		// 先从缓存中获取，如果存在于缓存，直接返回
		Player value = this.cache.get(key);
		if (value != null) {
			return value;
		}
		ReentrantFutureTask<Player> task = null;
		for (;;) {
			Future otherTask = this.taskMap.get(key);
			if (otherTask == null) {
				if (task == null) {
					task = createTask(new LoadTask(key));
				}
				otherTask = this.taskMap.putIfAbsent(key, task);
				// 获取了任务的执行权
				if (otherTask == null) {
					task.run();
					try {
						return task.get();
					} catch (ExecutionException ex) {
						throw ex.getCause();
					}
				}
			}
			Object result = null;
			try {
				result = otherTask.get();
			} catch (ExecutionException ex) {
				// ignore
			}
			if (result == null || result instanceof Boolean) {
				continue;
			}
			// 先看看是否已经存在缓存中，因为有可能其他人加载成功了
			value = this.cache.get(key);
			if (value != null) {
				return value;
			}
		}
	}

	public Player putIfAbsent(String key, Player value) {
		lock.lock();
		try {
			Player old = this.cache.get(key);
			if (old != null) {
				return old;
			}
			return this.cache.put(key, value);
		} finally {
			lock.unlock();
		}
	}

	private ReentrantFutureTask submitKeyTask(String key, ReentrantFutureTask task) throws InterruptedException, TimeoutException {
		ReentrantFutureTask otherTask = this.taskMap.get(key);
		if (otherTask == null) {
			otherTask = this.taskMap.putIfAbsent(key, task);
			// 获取了任务的执行权
			if (otherTask == null) {
				logger.info("add task：" + key + "," + task);
				return null;
			}
		}

		// 如果该任务是由当前线程执行，直接返回
		if (otherTask.getRunner() == Thread.currentThread()) {
			logger.warn("run in same thread：" + otherTask + "," + task);
			task.setUnderControl();
			return null;
		}

		// 这里执行其他操作可能会加载到内存
		try {
			otherTask.get(timeoutNanos, TimeUnit.SECONDS);
		} catch (ExecutionException ex) {
			// ignore
		} catch (TimeoutException e) {
			logger.error("等待超时：" + otherTask, e);
			throw e;
		}
		return otherTask;
	}

	/**
	 * 检测是否含有该键对应的数据
	 * 
	 * @param key
	 * @return
	 */
	public boolean containsKey(String key) {
		lock.lock();
		try {
			return this.cache.containsKey(key);
		} finally {
			lock.unlock();
		}
	}

	private ReentrantFutureTask getControlRight(String key, TaskCallable task) throws InterruptedException, TimeoutException {
		ReentrantFutureTask t = new ReentrantFutureTask(task);
		for (;;) {
			if (submitKeyTask(key, t) == null) {
				return t;
			}
		}
	}

	/** 构造一个ReentrantFutureTask **/
	private ReentrantFutureTask createTask(TaskCallable task) {
		ReentrantFutureTask t = new ReentrantFutureTask(task);
		return t;
	}

	/** 提交更新任务 **/
	private void submitUpdateTask(String key, int second, Callable callable) {
		if (this.delayUpdateMap.putIfAbsent(key, PRESENT) == null) {
			scheduledExecutor.schedule(callable, second, TimeUnit.SECONDS);
		}
	}

	/** 提交更新任务 **/
	private void submitUpdateTask(String key) {
		submitUpdateTask(key, updatePeriod, new UpdateTask(key));
	}

	class LoadTask extends TaskCallable<Player> {

		LoadTask(String key) {
			super(key);
		}

		@Override
		public Player call() throws Exception {
			Player v = loader.load(key);
			if (v != null) {
				Player old = PlayerCache.this.cache.putIfAbsent(key, v);
				return old == null ? v : old;
			}
			return null;
		}

		@Override
		public String getName() {
			return "loadTask";
		}

	}

	/** 缓存穿透清理任务 **/
	class PenetrantionTask implements Callable {

		private final String key;

		public PenetrantionTask(String key) {
			this.key = key;
		}

		@Override
		public Object call() throws Exception {
			penetrationCache.remove(key);
			return null;
		}

	}

	/** 元素剔除任务 **/
	class EvictedTask extends TaskCallable<Object> {

		private final Player value;

		public EvictedTask(String key, Player value) {
			super(key);
			this.value = value;
		}

		@Override
		public Object call() throws Exception {
			// 同步的数据库
			PlayerCache.this.delayUpdateMap.remove(key);
			loader.updateToDB(key, value);
			if (listener != null) {
				listener.notifyElementEvicted(key, value);
			}
			return null;
		}

		@Override
		public String getName() {
			// TODO Auto-generated method stub
			return null;
		}
	}

	/**
	 * 更新任务
	 **/
	class UpdateTask implements Callable {

		private final String key;
		private volatile int times;

		public UpdateTask(String key) {
			this.key = key;
		}

		@Override
		public Object call() throws Exception {
			// 更新任务必须保证互斥
			if (PlayerCache.this.delayUpdateMap.remove(key) == null) {
				logger.warn("updatetask已被执行：" + key);
				return null;
			}
			Player value = PlayerCache.this.cache.get(key);
			if (value == null) {
				logger.warn("执行更新任务时找不到：" + key);
				return null;
			}

//			List<PlayerUpdatedRecord> tasks = value.getUpdateTask();
//			int size = tasks.size();
//			for (int i = 0; i < size; i++) {
//				PlayerUpdatedRecord task = tasks.get(i);
//				if(task.getMapItemDAO().saveOrUpdate(task.getItem())){
//					
//				}
//			}

			return null;
		}
	}

	/**
	 * 获取缓存当前的大小
	 * 
	 * @return
	 */
	public int size() {
		lock.lock();
		try {
			return this.cache.size();
		} finally {
			lock.unlock();
		}
	}

	/**
	 * 获取缓存的最大容量
	 * 
	 * @return
	 */
	public int getMaxCapacity() {
		return this.capacity;
	}

	/**
	 * 获取缓存的更新周期，单位秒
	 * 
	 * @return
	 */
	public int getUpdatePeriod() {
		return this.updatePeriod;
	}

	/**
	 * 返回缓存键集合的拷贝
	 * 
	 * @return
	 */
	public List<String> keys() {
		lock.lock();
		try {
			return new ArrayList<String>(this.cache.keySet());
		} finally {
			lock.unlock();
		}
	}

	/**
	 * 获取缓存key-value的拷贝
	 * 
	 * @return
	 */
	public Map<String, Player> entries() {
		lock.lock();
		try {
			int size = this.cache.size();
			LinkedHashMap<String, Player> map = new LinkedHashMap<String, Player>(size);
			for (Map.Entry<String, Player> entry : this.cache.entrySet()) {
				// map.put(entry.getKey(), entry.getValue().value);
				map.put(entry.getKey(), entry.getValue());
			}
			return map;
		} finally {
			lock.unlock();
		}
	}

	public PersistentLoader<String, Player> getLoader() {
		return loader;
	}

	public Runnable createCacheUpdatedTask() {
		final Map<String, Player> map = entries();
		return new Runnable() {

			@Override
			public void run() {
				for (Map.Entry<String, Player> entry : map.entrySet()) {
					loader.updateToDB(entry.getKey(), entry.getValue());
				}
			}
		};
	}

	abstract class TaskCallable<T> implements Callable<T> {

		final String key;

		public TaskCallable(String key) {
			this.key = key;
		}

		public abstract String getName();
	}

	private class ReentrantFutureTask<V> extends FutureTask<V> {

		private final TaskCallable task;
		private volatile Thread runner;
		private volatile boolean controller;

		public ReentrantFutureTask(TaskCallable<V> task) {
			super(task);
			this.task = task;
			this.controller = true;
		}

		public void setUnderControl() {
			this.controller = false;
		}

		@Override
		public void run() {
			try {
				if (runner == null) {
					this.runner = Thread.currentThread();
				}
				super.run();
			} finally {
				if (controller) {
					Future old = PlayerCache.this.taskMap.remove(task.key);
					if (old != this) {
						logger.error("remove other task, current = " + task + ",old = " + old);
					}
				}
			}
		}

		public Thread getRunner() {
			return this.runner;
		}

		public String toString() {
			return task.getName();
		}

	}

	public Map getTaskMap() {
		return this.taskMap;
	}

	List<Player> getCacheCopy() {
		lock.lock();
		try {
			return new ArrayList<Player>(this.cache.values());
		} finally {
			lock.unlock();
		}
	}

	private Map<String, Player> getCopy() {
		lock.lock();
		try {
			return new LinkedHashMap<String, Player>(this.cache);
		} finally {
			lock.unlock();
		}
	}

	public CacheLogger getLogger() {
		return this.logger;
	}

}

class A {
	private void exeucte() {
		System.out.println("==============");
	}
}

class B extends A {
	public void execute() {
	}
}
