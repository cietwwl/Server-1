package com.rwbase.common.cache;

import com.rw.fsutil.cacheDao.mapItem.IMapItem;
import com.rw.fsutil.cacheDao.mapItem.MapItemDao;

public interface PlayerUpdatedRecord {

	/**
	 * 获取MapItemDAO
	 * @return
	 */
	public MapItemDao<IMapItem> getMapItemDAO();
	
	/**
	 * 获取MapItem实体
	 * @return
	 */
	public IMapItem getItem();
	
	/**
	 * 获取角色ID
	 * @return
	 */
	public String getUserId();
}
