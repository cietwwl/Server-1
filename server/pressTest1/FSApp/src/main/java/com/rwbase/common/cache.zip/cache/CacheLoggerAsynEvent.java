package com.rwbase.common.cache;

public interface CacheLoggerAsynEvent {

	/**
	 * 产生一个logger
	 * @return
	 */
	public String createLogger();
	
}
