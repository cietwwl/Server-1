package com.bm.groupSecret.cfg;

public class GroupSecretCfg {

	private String id;

	// 秘境持续时间
	private long duration;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public long getDuration() {
		return duration;
	}

	public void setDuration(long duration) {
		this.duration = duration;
	}

}
