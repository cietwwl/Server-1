package com.rw.handler.store;

import java.util.ArrayList;
import java.util.List;

import com.rw.dataSyn.SynItem;


public class StoreData implements SynItem{

	private String id; // ownerId + type 装备唯一id
	private List<CommodityData> commodity = new ArrayList<CommodityData>();
	private int refreshNum;
	private long lastRefreshTime;
	private eStoreExistType existType;
	private eStoreType type;
	private int version;
	
	public List<CommodityData> getCommodity() {
		return commodity;
	}
	public void setCommodity(List<CommodityData> commodity) {
		this.commodity = commodity;
	}
	public int getRefreshNum() {
		return refreshNum;
	}
	public void setRefreshNum(int refreshNum) {
		this.refreshNum = refreshNum;
	}
	public long getLastRefreshTime() {
		return lastRefreshTime;
	}
	public void setLastRefreshTime(long lastRefreshTime) {
		this.lastRefreshTime = lastRefreshTime;
	}
	public eStoreExistType getExistType() {
		return existType;
	}
	public void setExistType(eStoreExistType existType) {
		this.existType = existType;
	}
	public eStoreType getType() {
		return type;
	}
	public void setType(eStoreType type) {
		this.type = type;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
}
