package com.rw.handler.store;

public enum eStoreExistType {
	Always,//总是
	Interval;//间隔内
}
