package com.rw.dataSyn.fieldFromJson;

public interface IFieldFromJson {
	
	public void FromJson (Object target, String json);
	
}
