package com.rw.mutiTest;

public class MutiTestAccount {

	
	public static String preName = "vAUser101";

	public static int totalCount = 500;

	public static int start = 0;
	
	public static int threadCount = 500;
}
