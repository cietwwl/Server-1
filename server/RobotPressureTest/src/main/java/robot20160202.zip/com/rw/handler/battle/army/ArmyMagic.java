package com.rw.handler.battle.army;


public class ArmyMagic {

	private int modelId;
	private int level;

	public ArmyMagic() {
	}


	public int getModelId() {
		return modelId;
	}

	public void setModelId(int modelId) {
		this.modelId = modelId;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

}
