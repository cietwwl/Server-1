package com.rw.handler.store;


public class CommodityData {
	private int id;
	private int count;
	private int solt;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getSolt() {
		return solt;
	}
	public void setSolt(int solt) {
		this.solt = solt;
	}
}
