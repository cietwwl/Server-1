package com.rw.dataSyn;

public interface SynItem {

	public String getId();
	
}
